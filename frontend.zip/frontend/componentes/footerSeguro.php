  <footer class="text-center text-lg-start text-muted pt-3 bg-success-subtle">
         <section class="">
            <div class="container text-center">
                <div class="row">
                    <div class="col text-center mb-3">
                        <div class="me-5 d-none d-lg-block">
                            <span>Conecte-se conosco nas redes sociais:</span>
                        </div>
                        <div class="me-5 d-none d-lg-block fs-2">
                            <a href="#" class="me-4 text-reset"><i class="bi bi-facebook"></i></a>
                            <a href="#" class="me-4 text-reset"><i class="bi bi-instagram"></i></a>
                            <a href="#" class="me-4 text-reset"><i class="bi bi-youtube"></i></a>
                            <a href="#" class="me-4 text-reset"><i class="bi bi-whatsapp"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="text-center p-4 bg-success bg-gradient text-white">
            © 2024 Salão de Beleza. Todos os direitos reservados.
        </div>
    </footer>
    <script src="../../assets/js/script.js"></script>
    <!--Script do Bootstrap-->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
    